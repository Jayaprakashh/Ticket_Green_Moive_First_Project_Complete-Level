
 module.exports = function($scope, $rootScope, TodoService, $location) {


//   //$scope.cancellation = 'cancellation';
   $scope.bcontact = $rootScope.bookingDetails;
//  $scope.amt=$rootScope.amt1;
//   console.log($scope.bcontact);
//alert("YOUR TICKET IS CONFIRMATION");
  




// $scope.Ticketconfirmation =""
 $scope.getTicket = function(){
   	  alert("YOUR TICKET IS CONFIRMED");
   	  $location.path('/home');
       $route.reload();
      };

  
  };
