
module.exports = function($scope, $rootScope, $http, TodoService) {
  $scope.cancellation = 'cancellation';
  $scope.bcontact = "";
  $scope.cancellationId =""

   $scope.getCancellation = function(){
             $http.delete('/book/book/' + $scope.cancellationId)
                        .success(function(response){
                           console.log(response);
                            $scope.bcontact = response;
                            alert("CANCELLATION YOUR TICKET");
                        });
      };

};
