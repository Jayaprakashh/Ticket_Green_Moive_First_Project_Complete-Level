'use strict';
module.exports= function($scope,$http){



$('#book').click(function(){

	window.location.href='../views/hindi.html';
   });






}