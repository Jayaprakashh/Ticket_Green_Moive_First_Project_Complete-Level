'use strict';

module.exports = function($scope, $http) {
  $scope.admin = 'admin';

  $(document).ready(function() {
    $("div.bhoechie-tab-menu>div.list-group>a").click(function(e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
    });
});
  
var refresh = function () {
        $http.get('/city/city').success(function (response) {
            console.log('READ IS SUCCESSFUL');
            $scope.loginlist = response;
            $scope.logincontact = "";
        });
    };

    refresh();

     $scope.editlogin = function (id) {
         $http.get('/login/login/' + id._id).success(function (response) {
            $scope.logincontact = response[0];

  // function check(form)/*function to check userid & password*/
//{
 /*the following code checkes whether the entered userid and password are matching*/
 if(form.username.value == "loginname" && form.password.value == "loginpass")
  {
    window.open('home.html')/*opens the target page while Id & password matches*/
  }
 else
 {
   alert("Error Password or Username")/*displays error message*/
  }
//}

        });
    };
};