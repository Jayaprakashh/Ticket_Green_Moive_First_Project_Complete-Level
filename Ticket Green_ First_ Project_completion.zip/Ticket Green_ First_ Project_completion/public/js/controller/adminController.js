
'use strict';

module.exports = function($scope, $http) {
  $scope.admin = 'admin';

  $(document).ready(function() {
    $("div.bhoechie-tab-menu>div.list-group>a").click(function(e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
    });
});

//OMDB
  (function(){
    
    var getMovieInfo = function($http){
      
      var getshowinfo = function(showinfo){
            return $http.get('/movieinfo/movieinfo')
                        .then(function(response){
                           return response.data; 
                        });
      };
  
      return {
          get: getshowinfo
      };
        
    };
    
    var module = angular.module('movieApp');
    module.factory('getMovieInfo', getMovieInfo);
    
}());

  // city Dropdownlist

(function(){
    
    var userRepoService = function($http){
      
      var getUsers = function(username){
            return $http.get('/city/city')
                        .then(function(response){
                           return response.data; 
                        });
      };
  
      return {
          get: getUsers
      };
        
    };
    
    var module = angular.module('movieApp');
    module.factory('userRepoService', userRepoService);
    
}());


//theatre dropdown

(function(){
    
    var userRepoService1 = function($http){
      
      var getUsers1 = function(username1){
            return $http.get('/threatre/threatre')
                        .then(function(response){
                           return response.data; 
                        });
      };
  
      return {
          get: getUsers1
      };
        
    };
    
    var module = angular.module('movieApp');
    module.factory('userRepoService1', userRepoService1);
    
}());





  
var refresh = function () {
        $http.get('/city/city').success(function (response) {
            console.log('READ IS SUCCESSFUL');
            $scope.contactlist = response;
            $scope.contact = "";
        });
    };

    refresh();

    $scope.addMovie = function () {
        console.log($scope.contact);
        $http.post('/city/city', $scope.contact).success(function (response) {
            console.log(response);
            console.log("CREATE IS SUCCESSFUL");
            refresh();
        });
    };

    $scope.removeMovie = function (id) {
        console.log(id);
        $http.delete('/city/city/' + id._id).success(function (response) {
            console.log(response);
            console.log('DELETED SUCCESSFULLY');
            refresh();
        });
    };

    $scope.editMovie = function (id) {
         $http.get('/city/city/' + id._id).success(function (response) {
            $scope.contact = response[0];
        });
    };

    $scope.updateMovie = function () {
        console.log("REACHED UPDATE");
        console.log($scope.contact._id);
        $http.put('/city/city/' + $scope.contact._id, $scope.contact).success(function (response) {
            console.log(response);
            refresh();
        })
    }
// threater crud
    var refresht = function () {
        $http.get('/threatre/threatre').success(function (response) {
            console.log('READ IS SUCCESSFUL');
            $scope.tlist = response;
            $scope.tcontact = "";
        });
    };
refresht();

    $scope.addt = function () {
        console.log($scope.tcontact);
        $http.post('/threatre/threatre', $scope.tcontact).success(function (response) {
            console.log(response);
            console.log("CREATE IS SUCCESSFUL");
            refresht();
        });
    };

     $scope.removet = function (id) {
        console.log(id);
        $http.delete('/threatre/threatre/' + id._id).success(function (response) {
            console.log(response);
            console.log('DELETED SUCCESSFULLY');
            refresht();
        });
    };

    $scope.editt = function (id) {
         $http.get('/threatre/threatre/' + id._id).success(function (response) {
            $scope.tcontact = response[0];
        });
    };

    $scope.updatet = function () {
        console.log("REACHED UPDATE");
        console.log($scope.tcontact._id);
        $http.put('/threatre/threatre/' + $scope.tcontact._id, $scope.tcontact).success(function (response) {
            console.log(response);
            refresht();
        })
    }

// showtime crud
    var refreshs = function () {
        $http.get('/time/time').success(function (response) {
            console.log('READ IS SUCCESSFUL');
            $scope.slist = response;
            $scope.scontact = "";
        });
    };
refreshs();

    $scope.adds = function () {
        console.log($scope.scontact);
        $http.post('/time/time', $scope.scontact).success(function (response) {
            console.log(response);
            console.log("CREATE IS SUCCESSFUL");
            refreshs();
        });
    };

     $scope.removes = function (id) {
        console.log(id);
        $http.delete('/time/time/' + id._id).success(function (response) {
            console.log(response);
            console.log('DELETED SUCCESSFULLY');
            refreshs();
        });
    };

    $scope.edits = function (id) {
         $http.get('/time/time/' + id._id).success(function (response) {
            $scope.scontact = response[0];
        });
    };

    $scope.updates = function () {
        console.log("REACHED UPDATE");
        console.log($scope.scontact._id);
        $http.put('/time/time/' + $scope.scontact._id, $scope.scontact).success(function (response) {
            console.log(response);
            refreshs();
        })
    }

// Offer crud
    var refresho = function () {
        $http.get('/offer/offer').success(function (response) {
            console.log('READ IS SUCCESSFUL');
            $scope.olist = response;
            $scope.ocontact = "";
        });
    };
refresho();

    $scope.addo = function () {
        console.log($scope.scontact);
        $http.post('/offer/offer', $scope.ocontact).success(function (response) {
            console.log(response);
            console.log("CREATE IS SUCCESSFUL");
            refresho();
        });
    };

     $scope.removeo = function (id) {
        console.log(id);
        $http.delete('/offer/offer/' + id._id).success(function (response) {
            console.log(response);
            console.log('DELETED SUCCESSFULLY');
            refresho();
        });
    };

    $scope.edito = function (id) {
         $http.get('/offer/offer/' + id._id).success(function (response) {
            $scope.ocontact = response[0];
        });
    };

    $scope.updateo = function () {
        console.log("REACHED UPDATE");
        console.log($scope.ocontact._id);
        $http.put('/offer/offer/' + $scope.ocontact._id, $scope.ocontact).success(function (response) {
            console.log(response);
            refresho();
        })
    }
// Movies crud   //retrieve from our own  database 
//     var refreshm = function () {
//         $http.get('/movie/movie').success(function (response) {
//             console.log('READ IS SUCCESSFUL');
//             $scope.mlist = response;
//             $scope.mcontact = "";
//         });
//     };
// refreshm();

//     $scope.addm = function () {
//         console.log($scope.mcontact);
//         $http.post('/movie/movie', $scope.mcontact).success(function (response) {
//             console.log(response);
//             console.log("CREATE IS SUCCESSFUL");
//             refreshm();
//         });
//     };

//      $scope.removem = function (id) {
//         console.log(id);
//         $http.delete('/movie/movie/' + id._id).success(function (response) {
//             console.log(response);
//             console.log('DELETED SUCCESSFULLY');
//             refreshm();
//         });
//     };


    // $scope.editm = function (id) {
    //      $http.get('/movie/movie/' + id._id).success(function (response) {
    //         $scope.mcontact = response[0];
    //     });
    // };

    // $scope.updatem = function () {
    //     console.log("REACHED UPDATE");
    //     console.log($scope.mcontact._id);
    //     $http.put('/movie/movie/' + $scope.mcontact._id, $scope.mcontact).success(function (response) {
    //         console.log(response);
    //         refreshm();
    //     })
    // }

//Moive crud //retrieve from omdb 

      var movieObj={};

$scope.getData = function(){
  console.log('Hi Welcome')
  $http.get('http://www.omdbapi.com/?t='+$scope.movieObj.Title+'&plot=short&r=json',{data:"aishu"}).success(function (response) {
      console.log(response);
     // var movieObj={};
      for(var key in response){
      if(key=='Title'|| key=='Year' || key== 'Language' || key== 'Poster' || key== 'Genre' || key== 'Director' || key== 'Actors')
      {
      movieObj[key] = response[key];
      }
     
    console.log(movieObj);

      }
           refresh5();
  });
}



                        var refresh5 = function () {
                            $http.get('/movie/movie').success(function (response) {
                                console.log('READ IS SUCCESSFUL');
                                $scope.movieObj = response;
                                $scope.moviess = "";
                            });
                        };

                    refresh5();




                          $scope.addom = function () {
                              console.log(movieObj);
                              $http.post('/movie/movie',movieObj).success(function (response) {
                                  console.log(response);
                                  console.log("CREATE IS SUCCESSFUL");
                                  refresh5();
                              });
                          };

      
//MovieInfo crud
    var refreshminf = function () {
        $http.get('/movieinfo/movieinfo').success(function (response) {
            console.log('READ IS SUCCESSFUL');
            $scope.minflist = response;
            $scope.mcontact = "";
        });
    };
refreshminf();

    $scope.addminf = function () {
        console.log($scope.mcontact);
        $http.post('/movieinfo/movieinfo', $scope.mcontact).success(function (response) {
            console.log(response);
            console.log("CREATE IS SUCCESSFUL");
            refreshminf();
        });
    };

     $scope.removeminf = function (id) {
        console.log(id);
        $http.delete('/movieinfo/movieinfo/' + id._id).success(function (response) {
            console.log(response);
            console.log('DELETED SUCCESSFULLY');
            refreshminf();
        });
    };

    $scope.editminf = function (id) {
         $http.get('/movieinfo/movieinfo/' + id._id).success(function (response) {
            $scope.minfcontact = response[0];
        });
    };

    $scope.updateminf = function () {
        console.log("REACHED UPDATE");
        console.log($scope.minfcontact._id);
        $http.put('/movieinfo/movieinfo/' + $scope.minfcontact._id, $scope.minfcontact).success(function (response) {
            console.log(response);
            refreshminf();
        })
    }
 

//Booking CRUD Client side

 

};