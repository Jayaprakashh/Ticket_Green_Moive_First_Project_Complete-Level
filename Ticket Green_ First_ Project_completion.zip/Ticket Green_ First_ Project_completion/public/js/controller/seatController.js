//module.exports = function($scope, $rootScope, TodoService) {
  module.exports = function($scope,$rootScope, $route, $http,$location) {

$scope.bcontact="";
  //$scope.cancellation = 'cancellation';
  $scope.bcontact = $rootScope.bookingDetails;
 // $scope.amt=$rootScope.amt1;
  console.log($scope.bcontact);
 // alert("YOUR TICKET IS CONFIRMATION");
  

  

$scope.Ticketconfirmation ="";

$scope.boxNumber=function(){
  $scope.var=$scope.var+1;
  return $scope.var;
};
 $scope.getTicket = function(){
  	  alert("YOUR TICKET CONFIRMED");
};

/*$scope.cbm={
     	value1: 0,
     	value2: 0,
     	value3: 0,
     };
*/
$scope.checkedSeats=0;
$scope.seq=["A","B","C","D","E","F"];
$scope.seats=[];
$scope.checkboxes=[];
for(var i=0, x=1;i<10;i++){
  $scope.seats[i]=new Array(6);  
  $scope.checkboxes[i]=new Array(6);
  for(var j=0;j<6;j++){
    var s=""+(i+1)+$scope.seq[j];    
    $scope.seats[i][j]={id: x, value: 0, seat: s};
    $scope.checkboxes[i][j]={id: x, value: 0};
    x++;
  }  
}
$scope.checkChange=function(){  	
    $scope.checkedSeats=0;  
    console.log($scope.checkboxes);  
for(var i=0, x=0;i<10;i++){  
    for(var j=0;j<6;j++){
      x++;
    if($scope.checkboxes[i][j]==1){
      $scope.checkedSeats+=$scope.checkboxes[i][j];            
    }
    //console.log("Checked Seats "+$scope.checkedSeats);
  }  
} 
};

$scope.confirmBooking = function () {
        console.log("Checked Seats "+$scope.checkedSeats);
        //$http.post('/confirm', $scope.bcontact).success(function (response) {
        //    console.log(response);
            console.log("Confirm Booking");
            $scope.bcontact.Bseat=" ";
            var d=new Date();
            $scope.bcontact.Bid=d.getTime();

            //refreshb();
      for(var i=0, x=0;i<10;i++){  
          for(var j=0;j<6;j++){            
          if($scope.checkboxes[i][j]==1){
            $scope.bcontact.Bseat+=$scope.seats[i][j].seat+" "        
          }
        }  
      }
      $rootScope.bookingDetails=$scope.bcontact; 
      $rootScope.amt=$scope.checkedSeats*100;

            $location.path('/confirm');
            $route.reload();
      //  });
};


// var refreshb = function () {
//         $http.get('/book/book').success(function (response) {
//             console.log('READ IS SUCCESSFUL');
//             $scope.blist = response;
//             $scope.bcontact = "";
//         });
//     };
// refreshb();

//     $scope.addseat = function () {
//         console.log($scope.bcontact);
//         $http.post('/book/book', $scope.bcontact).success(function (response) {
//             console.log(response);
//             console.log("CREATE IS SUCCESSFUL");
//             //refreshb();
//             $rootScope.bookingDetails = $scope.bcontact;
//             $rootScope.amt1=$scope.amt;
//             $location.path('/confirm');
//             $route.reload();
//         });
//     };


// var myApp = angular.module("	", []);
//  myApp.controller("seatController", function($scope) {
// $scope.selectedCheckboxes = '';
//  $scope.getSelectedCheckboxes= function(myCheckbox) {
//      // copy data	 
// 	 //alert(myCheckbox);
// 	 $scope.selectedCheckboxes = angular.copy(myCheckbox);
//         // or you can get the checkbox values individually as below 
//         //$scope.value1 = myCheckbox.value1;
//         //$scope.value2 = myCheckbox.value2;
//        //  $scope.value3 = myCheckbox.value3;
//         //$scope.value4 = myCheckbox.value4;
//  };
// });
 //$scope.txtSeats=$scope.cbm1+$scope.cbm2+$scope.cbm3;

 };


