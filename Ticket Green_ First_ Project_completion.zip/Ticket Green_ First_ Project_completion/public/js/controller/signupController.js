// var app = angular.module('movieApp', ['UserValidation']);

// angular.module('UserValidation', []).directive('validPasswordC', function () {
//     return {
//         require: 'ngModel',
//         link: function (scope, elm, attrs, ctrl) {
//             ctrl.$parsers.unshift(function (viewValue, $scope) {
//                 var noMatch = viewValue != scope.myForm.password.$viewValue
//                 ctrl.$setValidity('noMatch', !noMatch)
//             })
//         }
//     }
// 


'use strict';

module.exports = function($scope, $http) {
  $scope.admin = 'admin';

  $(document).ready(function() {
    $("div.bhoechie-tab-menu>div.list-group>a").click(function(e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
    });
});
  
// var refreshsign = function () {
//         $http.get('/signup/signup').success(function (response) {
//             console.log('READ IS SUCCESSFUL');
//             $scope.signcontactlist = response;
//             $scope.signcontact = "";
//         });
//     };

//     refreshsign();

     $scope.addsign = function () {
    //     console.log($scope.signcontact);
    //     $http.post('/signup/signup', $scope.signcontact).success(function (response) {
    //         console.log(response);
    //         console.log("");

      var password = document.getElementById("password")
      var confirm_password = document.getElementById("password_confirm");

function validatePassword(){
   if(password.value != confirm_password.value) {
       alert("Passwords Don't Match");
   } else {
     alert('');
   }
 }

 password.onchange = validatePassword;
 confirm_password.onkeyup = validatePassword;

//             alert("Registered successfully");
//             refreshsign();
//         });
     };
};