'use strict';

var app = require('angular').module('movieApp');

app.controller('BookingController', require('./bookingController'));
app.controller('CancellationController', require('./cancellationController'));
app.controller('HomeController', require('./homeController'));
app.controller('AdminController', require('./adminController'));
app.controller('LoginController', require('./loginController'));
app.controller('SignupController', require('./signupController'));
app.controller('TamilController', require('./tamilController'));
app.controller('HindiController', require('./hindiController'));
app.controller('EnglishController', require('./englishController'));
app.controller('ShowingController', require('./showingController'));
app.controller('ComingController', require('./comingController'));
app.controller('ConfirmController', require('./confirmController'));
app.controller('SeatController', require('./seatController'));