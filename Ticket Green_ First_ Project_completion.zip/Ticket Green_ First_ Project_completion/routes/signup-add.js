var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser'); //parses information from POST
router.use(bodyParser.urlencoded({ extended: true }));


var mongoose = require('mongoose');


// var dbHost = 'mongodb://localhost:27017/test';
// mongoose.connect(dbHost);



var signupSchema = mongoose.Schema({
	username:String,
  email:String,
  password:String,
  password_confirm:String

 });
var SIGMODEL = mongoose.model('SIGMODEL', signupSchema, 'signup');

router.get('/signup', function (req, res) {
    console.log("REACHED GET ID FUNCTION ON SERVER");
     SIGMODEL.find({}, function (err, docs) {
         res.json(docs);
         
    });

});

//   router.get('/signup/:id', function (req, res) {
//     console.log("REACHED GET ID FUNCTION ON SERVER");
//      SIGMODEL.find({_id: req.params.id}, function (err, docs) {
//          res.json(docs);
         
//     });
// });

router.post('/signup', function(req, res){   //inserted to db
  console.log(req.body);
  var uname = req.body.username;
  var uemail = req.body.email;
  var upass=req.body.password;
  var upassconf = req.body.password_confirm;

  var sigobj = new SIGMODEL({

 username: uname,
 email : uemail,
 password : upass,
 password_confirm : upassconf
     
  });

  sigobj.save(function(err, docs){
    if ( err ) throw err;
    console.log("Registred Successfully");
    res.json(docs);
  });

})
  // catch 404 and forward to error handler
router.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});


  module.exports = router;