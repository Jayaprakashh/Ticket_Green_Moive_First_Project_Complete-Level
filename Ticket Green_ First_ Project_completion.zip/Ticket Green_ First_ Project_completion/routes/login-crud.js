var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser'); //parses information from POST
router.use(bodyParser.urlencoded({ extended: true }));


var mongoose = require('mongoose');


// var dbHost = 'mongodb://localhost:27017/test';
// mongoose.connect(dbHost);



var loginSchema = mongoose.Schema({
	  loginname:String,
    loginpass: String
 
 });

var LMODEL = mongoose.model('LMODEL', loginSchema, 'login');

 router.get('/login/:id', function (req, res) {
    console.log("REACHED GET ID FUNCTION ON SERVER");
     LMODEL.find({_loginpass: req.params.id}, function (err, docs) {
         res.json(docs);
         
    });
});
  // catch 404 and forward to error handler
router.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});


  module.exports = router;